const PORT=5000;
const express= require("express");
const app=express();
//const mongoose= require("mongoose");
const jwt= require("jsonwebtoken");
const multer= require("multer");
const path=require("path");
const cors=require("cors");

app.use(express.json());
app.use(cors());

//const userRoutes = require("./model/userschema");

//database connectin with mogodb

//mongoose.connect("mongodb+srv://beastjrpro:raphel007@cluster0.iiysasz.mongodb.net/ecommerce");



//app.get("/",(req,res)=>{
  // res.send("express app is running")
//})

//app.listen(port,()=>{
  //  if(!error){
    //    console.log("server running on port"+port)
    //}
    //else 
    //{
      //  console.log("error :"+error)
    //}
//})

const mongoose = require("mongoose");
//const { stringify } = require("querystring");
//const MDB_CONNECTION_STR ="mongodb+srv://beastjrpro:raphel007@cluster0.iiysasz.mongodb.net/ecommerce";
const MDB_CONNECTION_STR="mongodb+srv://jerald_raphel:raphel007@cluster0.iiysasz.mongodb.net/e-commerce"
//mongoose.connect(process.env.mongo_url)
//const projectRoutes = require("./routes/projectRoutes")

//middle ware

app.get("/",(req,res)=>{
  res.send("express app is running")
})


//image storage ingine



const storage= multer.diskStorage({
  destination: './upload/images',
  
  filename:(req,file,cb)=>{
    return cb(null,`${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`)
    
  }
  
})


const upload = multer({storage:storage})
console.log("storage");

// creating upload endpint for images

app.use('/images',express.static('upload/images'))
app.post("/upload",upload.single('product'),(req,res)=>{
    res.json({
      success:1,
      image_url:`http://localhost:${PORT}/images/${req.file.filename}`
    })
})


//schema for creating product


const product = mongoose.model("Product",{
  id:{
    type: Number,
    required:true
  },
  name:{
    type:String,
    required:true
  },
  image:{
    type:String,
    required:true
  },
  category:{
    type:String,
    required:true
  },
  new_price:{
    type:Number,
    required:true
  },
  old_price:{
    type:Number,
    required:true
  },
  date:{
    type:Date,
    default:Date.now,
  },
  avilable:{
    type:Boolean,
    default:true
  },

})



app.post("/addproduct",async(req,res)=>{
  const product= await new product({
    id:req.body.id,
    name:req.body.name,
    image:req.body.image,
    category:req.body.category,
    new_price:req.body.new_price,
    old_price:req.body.old_price,
  });
  console.log(String);
  console.log(product);
  await product.save();
  console.log("saved");
  res.json({
    success:true,
    name:req.body.name,
  })
})



//app.use((req,res , next) => {
  //  next();
//});
//app.use("/api/project",projectRoutes);

//data base connection


mongoose.connect(MDB_CONNECTION_STR).then(()=>{
    console.log("hey! connected successfully");

    app.listen(PORT,() => {
        console.log(`project dashboard - listening to ${PORT}`);
   })
});
console.log("welcome");